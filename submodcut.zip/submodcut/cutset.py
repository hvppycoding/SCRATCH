
from collections import defaultdict
from typing import Dict, Set, List, Tuple
from .ir import Module, Instance, ModuleLib
from .blast import blast, Bit
from .portdir import get_port_dir

# For each bit, track drivers/loads from S (move set) or R (rest)
def compute_cutset(mod: Module, move_names: Set[str], modlib: ModuleLib):
    drivers = defaultdict(set)  # bit -> {'S','R'}
    loads   = defaultdict(set)  # bit -> {'S','R'}

    # assigns inside target module (R side)
    for a in mod.assigns:
        for b in blast(a.lhs):
            drivers[b].add('R')
        for b in blast(a.rhs):
            loads[b].add('R')

    # instances
    for inst in mod.instances:
        side = 'S' if inst.name in move_names else 'R'
        for port, expr in inst.conns.items():
            bits = blast(expr)
            d = get_port_dir(modlib, inst.type, port)
            if d in ('output','inout'):
                for b in bits: drivers[b].add(side)
            if d in ('input','inout'):
                for b in bits: loads[b].add(side)

    # Determine boundary bits & directions
    ports: Dict[Bit, str] = {}  # bit -> dir
    for bit in set(list(drivers.keys()) + list(loads.keys())):
        Sside = ('S' in drivers[bit]) or ('S' in loads[bit])
        Rside = ('R' in drivers[bit]) or ('R' in loads[bit])
        if not (Sside and Rside):
            continue
        dS, dR = ('S' in drivers[bit]), ('R' in drivers[bit])
        lS, lR = ('S' in loads[bit]),   ('R' in loads[bit])
        if dS and not dR and lR:
            direction = 'output'
        elif dR and not dS and lS:
            direction = 'input'
        elif dS and dR:
            direction = 'inout'
        else:
            direction = 'inout'  # conservative fallback
        ports[bit] = direction

    return ports  # mapping of bit -> direction
