
import re
from typing import Dict, List, Tuple
from .ir import Module, Instance, Assign, NetRef, Slice, Concat, Replicate, ConstBit, Expr

# NOTE: This is a pragmatic, tolerant parser for typical patterns.
# It does NOT aim to implement full Verilog. It's used only if pyverilog is unavailable.

def parse_target_module_text(modname: str, text: str) -> Module:
    # Try to locate 'module modname ... endmodule' and slice that region
    pattern = re.compile(rf"module\s+{re.escape(modname)}\b(.*?)endmodule", re.S)
    m = pattern.search(text)
    if not m:
        raise ValueError(f"Module {modname} not found in text")
    body = m.group(1)
    body_lines = body.splitlines()
    base_line = text[:m.start(1)].count('\n') + 1  # 1-based start line for body

    # Extract assigns
    assigns: List[Assign] = []
    for am in re.finditer(r"assign\s+(.*?)\s*=\s*(.*?);", body, re.S):
        lhs = parse_expr(am.group(1))
        rhs = parse_expr(am.group(2))
        assigns.append(Assign(lhs, rhs))

    # Extract instances: type name ( .p(expr), ... );
    insts: List[Instance] = []
    # robust-ish pattern capturing balanced parens
    inst_pat = re.compile(r"([A-Za-z_\\$][A-Za-z0-9_\\$]*)\s+([A-Za-z_\\$][A-Za-z0-9_\\$]*)\s*\((.*?)\);", re.S)
    for im in inst_pat.finditer(body):
        itype, iname, blob = im.group(1), im.group(2), im.group(3)
        # Skip if it's 'module' declaration accidentally matched
        if itype == 'module':
            continue
        conns = {}
        # .port(expr)
        for cm in re.finditer(r"\.([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)", blob, re.S):
            pname = cm.group(1)
            expr  = parse_expr(cm.group(2))
            conns[pname] = expr
        # compute srcloc roughly
        start_char = im.start()
        start_line = body[:start_char].count('\n') + 1 + base_line
        end_line   = body[:im.end()].count('\n') + 1 + base_line
        insts.append(Instance(itype, iname, conns, (start_line, end_line)))

    return Module(name=modname, body_text=body, start_line=base_line, end_line=base_line+len(body_lines)-1,
                  assigns=assigns, instances=insts)

# --- Expression parser (very small subset) ---
def parse_expr(s: str) -> Expr:
    s = s.strip()
    # constants
    if s == "1'b0" or s == "1'b0" or s == "1'b0" or s == "1'b0":  # forgive duplicates
        return ConstBit(0)
    if s == "1'b1":
        return ConstBit(1)
    # concat: {a,b,c}
    if s.startswith('{') and s.endswith('}'):
        inside = s[1:-1]
        parts = split_top_commas(inside)
        return Concat([parse_expr(p) for p in parts])
    # replicate: {N{expr}}
    m = re.match(r"\{\s*(\d+)\s*\{(.*)\}\s*\}", s, re.S)
    if m:
        count = int(m.group(1))
        inner = parse_expr(m.group(2))
        return Replicate(count, inner)
    # slice: a[msb:lsb]
    m = re.match(r"([A-Za-z_\\$][A-Za-z0-9_\\$]*)\s*\[\s*(-?\d+)\s*:\s*(-?\d+)\s*\]", s)
    if m:
        return Slice(m.group(1), int(m.group(2)), int(m.group(3)))
    # bit: a[i]
    m = re.match(r"([A-Za-z_\\$][A-Za-z0-9_\\$]*)\s*\[\s*(-?\d+)\s*\]", s)
    if m:
        from .ir import NetRef
        return NetRef(m.group(1), int(m.group(2)))
    # bare id -> treat as single bit [0]
    m = re.match(r"([A-Za-z_\\$][A-Za-z0-9_\\$]*)\Z", s)
    if m:
        return NetRef(m.group(1), 0)
    # default: try trimming; otherwise constant 0
    return ConstBit(0)

def split_top_commas(s: str) -> List[str]:
    out = []
    depth = 0
    cur = []
    for ch in s:
        if ch == '{':
            depth += 1
            cur.append(ch)
        elif ch == '}':
            depth -= 1
            cur.append(ch)
        elif ch == ',' and depth == 0:
            out.append(''.join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    if cur:
        out.append(''.join(cur).strip())
    return out
