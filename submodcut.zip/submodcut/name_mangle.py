
import re
from typing import Set

def sanitize_identifier(s: str) -> str:
    # Replace non-word with underscore, ensure not starting with digit
    s2 = re.sub(r'\W', '_', s)
    if re.match(r'^\d', s2):
        s2 = '_' + s2
    return s2

def bit_port_name(net: str, idx: int) -> str:
    # a[5] -> a_5
    base = sanitize_identifier(net) + '_' + str(idx)
    return base

def uniquify(name: str, taken: Set[str], prefix='__cut_') -> str:
    base = sanitize_identifier(name)
    if base not in taken:
        taken.add(base)
        return base
    k = 2
    while True:
        cand = f"{prefix}{base}__{k}"
        if cand not in taken:
            taken.add(cand)
            return cand
        k += 1
