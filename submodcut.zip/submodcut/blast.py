
from typing import List, Tuple
from .ir import Expr, NetRef, Slice, Concat, Replicate, ConstBit

Bit = Tuple[str, int]  # (net, bit index)  or ("CONST0"/"CONST1", 0)

def blast(expr: Expr) -> List[Bit]:
    if isinstance(expr, NetRef):
        if expr.bit is None:
            # treat as scalar bit 0 if unknown; this should be avoided upstream
            return [(expr.name, 0)]
        return [(expr.name, expr.bit)]
    elif isinstance(expr, Slice):
        msb, lsb = expr.msb, expr.lsb
        if msb >= lsb:
            return [(expr.name, i) for i in range(msb, lsb-1, -1)]
        else:
            return [(expr.name, i) for i in range(msb, lsb+1, 1)]
    elif isinstance(expr, Concat):
        out: List[Bit] = []
        for item in expr.items:
            out += blast(item)
        return out
    elif isinstance(expr, Replicate):
        inner = blast(expr.item)
        out: List[Bit] = []
        for _ in range(expr.count):
            out += inner
        return out
    elif isinstance(expr, ConstBit):
        return [("CONST1", 0)] if expr.value else [("CONST0", 0)]
    else:
        raise TypeError(f"Unsupported Expr type: {type(expr)}")

def emit_expr_from_bits(bits: List[Bit], one_bit_name_fn) -> str:
    # Emit Verilog expression (concat of bit identifiers). If one bit, no concat.
    ids = []
    for n,i in bits:
        if n == "CONST1":
            ids.append("1'b1")
        elif n == "CONST0":
            ids.append("1'b0")
        else:
            ids.append(one_bit_name_fn(n, i))
    if len(ids) == 1:
        return ids[0]
    return '{' + ', '.join(ids) + '}'
