
from dataclasses import dataclass
from typing import List, Tuple, Dict, Optional, Set, Any

def stable_unique(seq):
    seen = set()
    out = []
    for x in seq:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out
