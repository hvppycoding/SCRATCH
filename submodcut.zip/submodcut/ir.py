
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Union

# --- Expression Nodes ---
@dataclass
class NetRef:
    name: str
    bit: Optional[int] = None  # None means whole vector, but we try to avoid using this

@dataclass
class Slice:
    name: str
    msb: int
    lsb: int

@dataclass
class Concat:
    items: List['Expr']

@dataclass
class Replicate:
    count: int
    item: 'Expr'

@dataclass
class ConstBit:
    value: int  # 0 or 1

Expr = Union[NetRef, Slice, Concat, Replicate, ConstBit]

# --- IR Containers ---
@dataclass
class Assign:
    lhs: Expr
    rhs: Expr

@dataclass
class Instance:
    type: str
    name: str
    conns: Dict[str, Expr]  # port name -> Expr (bitwise blastable)
    srcloc: Tuple[int,int] = (0,0)  # (start_line, end_line) for rewriting

@dataclass
class Module:
    name: str
    body_text: str                          # raw verilog code for the module (for rewrite)
    start_line: int = 0
    end_line: int = 0
    nets: Dict[str, int] = field(default_factory=dict)  # net name -> width (optional)
    assigns: List[Assign] = field(default_factory=list)
    instances: List[Instance] = field(default_factory=list)

# Simple registry of modules for direction lookup
@dataclass
class ModuleLib:
    # modname -> {portname -> direction('input'/'output'/'inout')}
    ports: Dict[str, Dict[str, str]] = field(default_factory=dict)
