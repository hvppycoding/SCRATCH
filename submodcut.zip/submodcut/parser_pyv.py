
# Optional: use pyverilog if available
from typing import Optional, Dict, List
from .ir import Module, Instance, Assign, NetRef, Slice, Concat, Replicate, ConstBit, ModuleLib
try:
    from pyverilog.vparser.parser import parse
    from pyverilog.vparser.ast import ModuleDef, InstanceList, Instance as PVInstance, PortArg, Assign as PVAssign, Lvalue, Rvalue, Identifier, Pointer, Partselect, IntConst, Concat as PVConcat, Repeat
except Exception:
    parse = None

def parse_with_pyverilog(filepath: str, target_mod: str) -> Optional[Module]:
    if parse is None:
        return None
    ast, _ = parse([filepath], preprocess_include=[], preprocess_define=[])
    # Find target module node
    target = None
    for d in ast.description.definitions:
        if isinstance(d, ModuleDef) and d.name == target_mod:
            target = d
            break
    if target is None:
        return None

    body_lines = []
    # We don't have direct source text per module; leave empty and rely on rewrite fallback
    assigns: List[Assign] = []
    insts: List[Instance] = []

    def conv_expr(e):
        if isinstance(e, Identifier):
            return NetRef(e.name, 0)
        if isinstance(e, Pointer) and isinstance(e.var, Identifier):
            return NetRef(e.var.name, int(e.ptr.value))
        if isinstance(e, Partselect) and isinstance(e.var, Identifier):
            msb = int(e.msb.value); lsb = int(e.lsb.value)
            return Slice(e.var.name, msb, lsb)
        if isinstance(e, IntConst):
            v = int(e.value, 0)
            return ConstBit(1 if v&1 else 0)
        if isinstance(e, PVConcat):
            return Concat([conv_expr(x) for x in e.list])
        if isinstance(e, Repeat):
            count = int(e.times.value)
            return Replicate(count, conv_expr(e.value))
        return ConstBit(0)

    # collect assigns and instances
    for item in target.items:
        if isinstance(item, PVAssign):
            assigns.append(Assign(conv_expr(item.left), conv_expr(item.right)))
        if isinstance(item, InstanceList):
            for inst in item.instances:
                if isinstance(inst, PVInstance):
                    conns = {}
                    for pa in inst.portlist:
                        if isinstance(pa, PortArg):
                            conns[pa.portname] = conv_expr(pa.arg)
                    insts.append(Instance(item.module, inst.name, conns, (0,0)))
    return Module(name=target_mod, body_text='', assigns=assigns, instances=insts)

def extract_port_directions(filepath: str) -> ModuleLib:
    lib = ModuleLib()
    if parse is None:
        return lib
    ast, _ = parse([filepath], preprocess_include=[], preprocess_define=[])
    from pyverilog.vparser.ast import ModuleDef, Ioport, Input, Output, Inout, Portlist, Port
    for d in ast.description.definitions:
        if isinstance(d, ModuleDef):
            portdirs = {}
            for item in d.items:
                if isinstance(item, Ioport):
                    decl = item.first
                    if isinstance(decl, Input):
                        direction = 'input'
                    elif isinstance(decl, Output):
                        direction = 'output'
                    elif isinstance(decl, Inout):
                        direction = 'inout'
                    else:
                        continue
                    # item.symbol.name for Identifier
                    try:
                        name = decl.children()[0].name
                    except Exception:
                        continue
                    portdirs[name] = direction
            lib.ports[d.name] = portdirs
    return lib
