
import re
from typing import List, Tuple
from .ir import Module, Instance

def remove_instances_and_insert_sub(mod: Module,
                                    moved: List[Instance],
                                    replacement_line: str) -> str:
    # crude span-based removal: use recorded srcloc lines (1-based) relative to module.body_text lines
    lines = mod.body_text.splitlines()
    # Map srcloc to indices in 'lines' (assuming srcloc already relative to module block)
    remove_spans: List[Tuple[int,int]] = []
    for inst in moved:
        s,e = inst.srcloc
        if s <= 0 or e <= 0:
            # fallback: regex find by name
            pat = re.compile(rf"\b{re.escape(inst.type)}\s+{re.escape(inst.name)}\s*\(.*?\);", re.S)
            m = pat.search(mod.body_text)
            if m:
                # convert char spans to line numbers
                # remove using char spans after all concatenation
                pass
        remove_spans.append((s-1, e-1))  # make 0-based inclusive

    # Merge overlaps
    remove_spans.sort()
    merged = []
    for s,e in remove_spans:
        if not merged or s > merged[-1][1] + 1:
            merged.append([s,e])
        else:
            merged[-1][1] = max(merged[-1][1], e)

    # Build new lines array with removal and single insertion at first span start
    if not merged:
        # nothing to remove; append replacement at end
        return mod.body_text + "\n" + replacement_line + "\n"

    out = []
    insert_done = False
    cur = 0
    for s,e in merged:
        # keep lines before s
        while cur < s and cur < len(lines):
            out.append(lines[cur])
            cur += 1
        if not insert_done:
            out.append('    ' + replacement_line)
            insert_done = True
        # skip [s..e]
        cur = e+1
    # add remaining
    while cur < len(lines):
        out.append(lines[cur])
        cur += 1
    return '\n'.join(out)
