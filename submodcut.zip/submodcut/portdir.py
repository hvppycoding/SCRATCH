
from typing import Dict
from .ir import ModuleLib

def get_port_dir(modlib: ModuleLib, modname: str, port: str) -> str:
    table = modlib.ports.get(modname, {})
    d = table.get(port)
    if d in ('input', 'output', 'inout'):
        return d
    # unknown -> treat as inout (conservative)
    return 'inout'
