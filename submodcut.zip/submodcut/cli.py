
import argparse, os, sys, re
from typing import List, Set
from .parser_pyv import parse_with_pyverilog, extract_port_directions
from .parser_light import parse_target_module_text
from .ir import Module, ModuleLib
from .cutset import compute_cutset
from .emitter import build_submodule_text, build_submodule_instance_text
from .rewrite import remove_instances_and_insert_sub

def main():
    ap = argparse.ArgumentParser(description='Submodule cut: move instances into a new submodule with 1-bit ports.')
    ap.add_argument('verilog', help='Input Verilog file path')
    ap.add_argument('--target-module', required=True)
    ap.add_argument('--instances', nargs='+', required=True, help='Instance names to move')
    ap.add_argument('--submodule-name', default='cut_submod')
    ap.add_argument('--out', default='out.v')
    args = ap.parse_args()

    text = open(args.verilog, 'r', encoding='utf-8').read()

    # Try pyverilog for directions and structure; fall back to light parser
    mod = parse_with_pyverilog(args.verilog, args.target_module)
    if mod is None or not mod.instances:
        mod = parse_target_module_text(args.target_module, text)
    else:
        # If body_text missing, recover from light parser for rewrite lines
        try:
            mod2 = parse_target_module_text(args.target_module, text)
            mod.body_text = mod2.body_text
            mod.start_line = mod2.start_line
            mod.end_line = mod2.end_line
            # try to merge srcloc by instance name
            locmap = {i.name:i.srcloc for i in mod2.instances}
            for i in mod.instances:
                if i.name in locmap:
                    i.srcloc = locmap[i.name]
        except Exception:
            pass

    # Build module library of port directions
    modlib = extract_port_directions(args.verilog)

    move_set: Set[str] = set(args.instances)
    moved_insts = [i for i in mod.instances if i.name in move_set]
    if not moved_insts:
        print('No matching instances to move.', file=sys.stderr)
        sys.exit(2)

    ports = compute_cutset(mod, move_set, modlib)
    sub_text, bit2port = build_submodule_text(args.submodule_name, ports, moved_insts)
    sub_inst_text, _ = build_submodule_instance_text(args.submodule_name, bit2port)

    new_body = remove_instances_and_insert_sub(mod, moved_insts, sub_inst_text)

    # Stitch: replace original module region in file text
    full_text = text
    # find region of module
    import re
    pat = re.compile(rf"(module\s+{re.escape(args.target_module)}\b.*?endmodule)", re.S)
    m = pat.search(full_text)
    if not m:
        # fallback: append submodule only
        out_text = full_text + '\n\n' + sub_text
    else:
        # replace the matched block with reconstructed header + new_body + endmodule
        block = m.group(1)
        # Attempt to split header/body/footer roughly
        mh = re.match(rf"module\s+{re.escape(args.target_module)}\b(.*)endmodule", block, re.S)
        if mh:
            header_prefix = f"module {args.target_module}"
            out_block = header_prefix + new_body + '\nendmodule'
            out_text = full_text[:m.start(1)] + out_block + full_text[m.end(1):]
        else:
            out_text = full_text[:m.start(1)] + new_body + full_text[m.end(1):]

    out_text += '\n\n' + sub_text

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(out_text)

    print(f'Wrote {args.out} with inserted submodule {args.submodule_name}')

if __name__ == '__main__':
    main()
