
from typing import Dict, Tuple, List, Set
from .blast import emit_expr_from_bits, blast, Bit
from .name_mangle import bit_port_name, uniquify, sanitize_identifier

# Build submodule definition and instantiation text
def build_submodule_text(submod_name: str, 
                         ports: Dict[Bit, str],
                         moved_insts,
                         port_order = ('input','output','inout')) -> Tuple[str, Dict[Bit,str]]:
    # ports: Bit->dir ; we need unique 1-bit port names
    taken: Set[str] = set()
    bit2port: Dict[Bit, str] = {}
    # stable order: by dir group, then by net name, then bit index
    def sort_key(item):
        (n,i), d = item
        return (port_order.index(d), n, i)
    items = sorted(ports.items(), key=sort_key)
    port_decls = []
    port_list = []
    for (net, idx), direction in items:
        if net in ('CONST0','CONST1'):
            # constants should not become ports; but boundary can't be const normally
            pname = uniquify(f'CONST_{idx}', taken)
        else:
            pname = bit_port_name(net, idx)
            if pname in taken:
                pname = uniquify(pname, taken)
            else:
                taken.add(pname)
        bit2port[(net,idx)] = pname
        port_decls.append(f"    {direction} {pname};")
        port_list.append(pname)

    # rebuild moved instances with new expr text
    inst_texts = []
    for inst in moved_insts:
        conns = []
        for p, expr in inst.conns.items():
            bits = blast(expr)
            def one_bit(n,i):
                return bit2port.get((n,i), bit2port.get((n,i)))  # must exist if boundary or internal; internal bit stays same name? We'll map missing to name directly
            # Missing -> internal-only bit: create local wire name same style
            def one_bit_safe(n,i):
                key = (n,i)
                if key in bit2port:
                    return bit2port[key]
                # internal bit: reference original name (flattened) within submodule
                return sanitize_identifier(n) + '_' + str(i)
            expr_txt = emit_expr_from_bits(bits, one_bit_safe)
            conns.append(f".{p}({expr_txt})")
        inst_texts.append(f"    {inst.type} {inst.name} (" + ', '.join(conns) + ");")

    # For internal-only bits we emitted like a_5, declare them as wires:
    # Collect all identifiers used in instance connections that are not in port_list
    used_ids = set()
    for t in inst_texts:
        for m in __import__('re').finditer(r'\b([A-Za-z_][A-Za-z0-9_]*)\b', t):
            used_ids.add(m.group(1))
    internal_wires = sorted(list(used_ids - set(port_list) - set(i.name for i in moved_insts) - set([submod_name])))
    wire_lines = [f"    wire {w};" for w in internal_wires if not w.startswith('CONST')]

    header = f"module {submod_name} (" + ', '.join(port_list) + ");\n"               + '\n'.join(port_decls) + ('\n' if port_decls else '')
    body = ('\n'.join(wire_lines) + ('\n' if wire_lines else '')) + '\n'.join(inst_texts) + '\n'
    footer = 'endmodule\n'
    return header + body + footer, bit2port

def build_submodule_instance_text(submod_name: str, bit2port: Dict[Bit,str]) -> Tuple[str, Dict[str, str]]:
    # instance that connects submodule ports back to original net bits in the parent
    # return text and mapping for tests
    # Stable port order:
    items = sorted(bit2port.items(), key=lambda kv: kv[1])
    conns = []
    revmap = {}
    for (net, idx), pname in items:
        if net == 'CONST0':
            arg = "1'b0"
        elif net == 'CONST1':
            arg = "1'b1"
        else:
            arg = f"{net}[{idx}]"
        conns.append(f".{pname}({arg})")
        revmap[pname] = arg
    txt = f"{submod_name} u_{submod_name} (" + ', '.join(conns) + ");"
    return txt, revmap
