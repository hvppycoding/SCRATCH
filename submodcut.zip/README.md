
# submodcut — Verilog instance submodularizer (bit-cut, concat/slice aware)

이 도구는 target module에서 선택한 instance들을 새 submodule로 옮기고, 경계 비트 컷셋을 계산해
**1-bit 포트**로 내보냅니다. concat/slice/replicate를 비트 단위로 처리하며, 원본 소스를 가능한 한
보존(인스턴스 블록만 치환)합니다. `pyverilog`가 가능하면 사용하고, 불가능하면 라이트 파서로 동작합니다.

## 설치/사용
```bash
python -m submodcut.cli path/to/top.v --target-module TOP --instances U1 U2 U3 --submodule-name my_cut --out out.v
```

- `--instances` 는 옮길 인스턴스 이름들.
- `--submodule-name` 새로 만들 서브모듈명.
- `--out` 결과 파일.

## 아이디어
- 표현식을 비트 리스트로 **blast** → concat/slice/replicate 모두 단순화
- 옮길 집합 S와 나머지 R 사이의 **컷셋 비트**에서, driver/load 분포로 **포트 방향 자동 결정**
- 서브모듈 포트는 **항상 폭 1, a[5]→a_5** 네이밍 (충돌 방지)
- 원본 모듈은 인스턴스 블록만 제거하고 **서브모듈 인스턴스 한 줄 삽입**

## 제한
- 라이트 파서는 Verilog 전체를 지원하진 않습니다(일반적인 연결/assign/인스턴스는 처리).
- pyverilog 미사용 시 포트 방향은 driver/load 분석으로 추론하고, 모호하면 inout 유지.
- 복잡한 generate/parameterized 파트셀렉트(+:/-:) 등은 단순화해서 처리합니다.
